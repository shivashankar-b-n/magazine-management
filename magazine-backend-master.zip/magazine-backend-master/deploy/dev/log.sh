#docker-compose --env-file .env.dev -f docker-dev.yml logs -f
docker logs dev_server_1 -f
