docker-compose --env-file .env.dev -f docker-dev.yml stop
