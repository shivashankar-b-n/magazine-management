exports.info = (tag, message) => {
  console.log(tag, message);
};

exports.error = (tag, message) => {
  console.log(tag, message);
};