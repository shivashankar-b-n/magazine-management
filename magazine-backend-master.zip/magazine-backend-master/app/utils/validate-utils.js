export const validateInputString = (input) => (typeof input !== 'string' || input.length === 0);
