module.exports = {
  extends: [
    'airbnb',
  ],
};
